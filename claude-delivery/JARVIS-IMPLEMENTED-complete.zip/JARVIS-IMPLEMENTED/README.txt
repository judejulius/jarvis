JARVIS-IMPLEMENTED  (see REPORT.md first)

project/        complete buildable repository: same layout as GitHub master, with every change applied
changed-files/  only the 55 modified/new files, same relative paths (for quick review)
patches/        all-changes.patch (apply with git apply) and per-file/*.diff
termux/         llama-server supervisor + one-time installer (also inside project/termux)
docs/           INSTALL, ARCHITECTURE, AUDIT, VERIFICATION, LIMITATIONS (also inside project/docs)
evidence/       input-evidence digest, file ledger, unit-test / compile / Termux-script / syntax logs
verify/         the local harness used for those logs (JUnit shim, Android stubs, scripts)
REPORT.md       final implementation report

Start with docs/INSTALL.md.
