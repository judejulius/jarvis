#!/usr/bin/env bash
# Type-checks the app's Kotlin sources against a real android.jar (API 34) and the Sherpa-ONNX classes, using small stubs for
# AndroidX/Material/OkHttp/Anthropic SDK (Maven is not reachable from this sandbox). This is a compile check only:
# it does not run Android code and does not replace the Gradle build.
# Usage: verify/compile-android.sh <project-root> <kotlinc-bin> <android.jar> <sherpa-classes.jar> [out]
set -uo pipefail
ROOT="$1"; KBIN="$2"; ANDROID="$3"; SHERPA="$4"; OUT="${5:-/tmp/jarvis-android-out}"
HERE="$(cd "$(dirname "$0")" && pwd)"
M="$ROOT/app/src/main/java"
mkdir -p "$OUT"
# Real sources, minus the pieces replaced by stubs (view-binding UI, Anthropic SDK, Settings fragment code).
mapfile -t SRC < <(find "$M" -name '*.kt' \
  ! -path '*/ui/*' ! -name 'AnthropicSession.kt' ! -name 'ModelDownloader.kt' | sort)
# TaskIsland is replaced by a stub with the same public API (the real one uses view binding).

# AssistantSection is checked with the Material stubs.
SRC+=("$M/com/jarvis/assistant/ui/AssistantSection.kt")
"$KBIN/kotlinc" -nowarn -cp "$ANDROID:$SHERPA" -d "$OUT/classes" "${SRC[@]}" "$HERE"/stubs/*.kt 2>&1 | grep -v "^warning" 
echo "exit-status-of-compile: ${PIPESTATUS[0]}"
