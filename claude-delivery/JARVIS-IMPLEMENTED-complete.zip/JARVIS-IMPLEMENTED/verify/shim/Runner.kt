// Tiny reflection runner for the JUnit shim: runs every @Test method of the given classes and prints PASS/FAIL.
import java.lang.reflect.InvocationTargetException

fun main(args: Array<String>) {
    var pass = 0
    var fail = 0
    for (name in args) {
        val c = Class.forName(name)
        val instance = c.getDeclaredConstructor().newInstance()
        for (m in c.declaredMethods.sortedBy { it.name }) {
            if (!m.isAnnotationPresent(org.junit.Test::class.java)) continue
            try {
                m.invoke(instance)
                pass++
                println("PASS ${c.simpleName}.${m.name}")
            } catch (e: InvocationTargetException) {
                fail++
                println("FAIL ${c.simpleName}.${m.name}: ${e.targetException}")
            }
        }
    }
    println("== $pass passed, $fail failed")
    if (fail > 0) System.exit(1)
}
