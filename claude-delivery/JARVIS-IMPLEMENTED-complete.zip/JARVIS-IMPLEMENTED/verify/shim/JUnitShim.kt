// Minimal stand-in for JUnit 4 so the repo's pure-Kotlin unit tests can run without Maven access.
// The real build uses the real JUnit (see app/build.gradle.kts); this file is NOT part of the app.
package org.junit

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FUNCTION)
annotation class Test

object Assert {
    @JvmStatic fun assertEquals(expected: Any?, actual: Any?) {
        if (expected != actual) throw AssertionError("expected:<$expected> but was:<$actual>")
    }
    @JvmStatic fun assertEquals(message: String, expected: Any?, actual: Any?) {
        if (expected != actual) throw AssertionError("$message expected:<$expected> but was:<$actual>")
    }
    @JvmStatic fun assertTrue(condition: Boolean) { if (!condition) throw AssertionError("expected true") }
    @JvmStatic fun assertTrue(message: String, condition: Boolean) { if (!condition) throw AssertionError(message) }
    @JvmStatic fun assertFalse(condition: Boolean) { if (condition) throw AssertionError("expected false") }
    @JvmStatic fun assertFalse(message: String, condition: Boolean) { if (condition) throw AssertionError(message) }
    @JvmStatic fun assertNull(actual: Any?) { if (actual != null) throw AssertionError("expected null but was:<$actual>") }
    @JvmStatic fun assertNotNull(actual: Any?) { if (actual == null) throw AssertionError("expected not null") }
    @JvmStatic fun assertNotEquals(a: Any?, b: Any?) { if (a == b) throw AssertionError("expected different values but both were:<$a>") }
    @JvmStatic fun fail(message: String) { throw AssertionError(message) }
}
