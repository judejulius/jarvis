#!/usr/bin/env bash
# Compiles the pure-Kotlin parts of JARVIS (no Android classes) with kotlinc and runs their unit tests
# through a tiny JUnit shim. Usage: verify/run-unit-tests.sh <project-root> <kotlinc-bin-dir> [out-dir]
set -euo pipefail
ROOT="${1:?project root}"; KBIN="${2:?kotlinc bin dir}"; OUT="${3:-/tmp/jarvis-verify}"
HERE="$(cd "$(dirname "$0")" && pwd)"
M="$ROOT/app/src/main/java/com/jarvis/assistant"; T="$ROOT/app/src/test/java/com/jarvis/assistant"
mkdir -p "$OUT"
PURE_MAIN=("$M/router/Lexicon.kt" "$M/router/Commands.kt" "$M/router/FastCommandRouter.kt" "$M/router/AppMatcher.kt" "$M/router/MemoryIntentParser.kt" "$M/ai/AiMode.kt" "$M/ai/Endpoints.kt" "$M/ai/RoutePolicy.kt")
[ -f "$M/ai/ServerHealth.kt" ] && PURE_MAIN+=("$M/ai/ServerHealth.kt")
[ -f "$M/memory/MemoryCore.kt" ] && PURE_MAIN+=("$M/memory/MemoryCore.kt")
[ -f "$M/util/LatencyTrace.kt" ] && PURE_MAIN+=("$M/util/LatencyTrace.kt")
[ -f "$M/agent/SensitiveActions.kt" ] && PURE_MAIN+=("$M/agent/SensitiveActions.kt")
PURE_TESTS=("$T"/router/*.kt "$T/ai/RoutePolicyTest.kt")
[ -f "$T/ai/ServerHealthTest.kt" ] && PURE_TESTS+=("$T/ai/ServerHealthTest.kt")
[ -f "$T/memory/MemoryCoreTest.kt" ] && PURE_TESTS+=("$T/memory/MemoryCoreTest.kt")
[ -f "$T/util/LatencyTraceTest.kt" ] && PURE_TESTS+=("$T/util/LatencyTraceTest.kt")
[ -f "$T/agent/SensitiveActionsTest.kt" ] && PURE_TESTS+=("$T/agent/SensitiveActionsTest.kt")
"$KBIN/kotlinc" -nowarn -d "$OUT/unit.jar" "${PURE_MAIN[@]}" "${PURE_TESTS[@]}" "$HERE/shim/JUnitShim.kt" "$HERE/shim/Runner.kt" 2>&1 | grep -v "^warning" || true
CLASSES=$(grep -hoE "^class [A-Za-z0-9]+Test" "${PURE_TESTS[@]}" | awk '{print $2}' | while read c; do f=$(grep -l "^class $c" "${PURE_TESTS[@]}" | head -1); pkg=$(grep -m1 '^package' "$f" | awk '{print $2}'); echo "$pkg.$c"; done)
"$KBIN/kotlin" -cp "$OUT/unit.jar" RunnerKt $CLASSES
