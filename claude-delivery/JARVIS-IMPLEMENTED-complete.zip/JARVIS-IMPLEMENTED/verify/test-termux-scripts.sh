#!/usr/bin/env bash
# Exercises termux/install-termux.sh, start-llama.sh and llama-supervisor.sh against a fake llama-server and a fake tmux:
# first run crashes, second run hangs (answers 503), third run is healthy. Verifies restart-on-crash, watchdog restart on
# hang, no duplicate servers, correct flags, and that install is idempotent. Linux only; it checks the shell logic, not Android.
set -u
ROOT="${1:?project root}"
T="$(mktemp -d)"; export HOME="$T/home"; mkdir -p "$HOME" "$T/bin"
export PATH="$T/bin:$PATH" FAKE_ARGS="$T/args.txt" FAKE_COUNT="$T/count.txt" PORT_UNDER_TEST=18091
fail=0; check() { if [ "$2" = "ok" ]; then echo "PASS $1"; else echo "FAIL $1 ($2)"; fail=1; fi; }

cat >"$T/bin/llama-server" <<'PY'
#!/usr/bin/env python3
import sys, http.server, threading, os
args = sys.argv[1:]
if '--help' in args:
    print("  -np, --parallel N\n  --cache-ram N"); sys.exit(0)
port = int(args[args.index('--port') + 1])
open(os.environ['FAKE_ARGS'], 'a').write(' '.join(args) + '\n')
cnt = os.environ['FAKE_COUNT']
n = int(open(cnt).read()) if os.path.exists(cnt) else 0
open(cnt, 'w').write(str(n + 1))
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(503 if n == 1 else 200); self.end_headers(); self.wfile.write(b'{}')
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(('127.0.0.1', port), H)
if n == 0: threading.Timer(3, lambda: os._exit(1)).start()
srv.serve_forever()
PY
cat >"$T/bin/tmux" <<'SH'
#!/usr/bin/env bash
D="${HOME}/.faketmux"; mkdir -p "$D"
case "$1" in
  new-session) name="$4"; nohup bash -c "$5" >/dev/null 2>&1 & echo $! >"$D/$name.pid" ;;
  has-session) [ -f "$D/$3.pid" ] && kill -0 "$(cat "$D/$3.pid")" 2>/dev/null ;;
  kill-session) [ -f "$D/$3.pid" ] && { pkill -P "$(cat "$D/$3.pid")" 2>/dev/null; kill "$(cat "$D/$3.pid")" 2>/dev/null; rm -f "$D/$3.pid"; } ;;
  ls) ls "$D" 2>/dev/null ;;
esac
SH
printf '#!/usr/bin/env bash\nexit 0\n' >"$T/bin/termux-wake-lock"
chmod +x "$T/bin/"*
mkdir -p "$HOME/jarvis/models"; : >"$HOME/jarvis/models/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"

# --- install: the test config exists first, so the installer keeps it and starts exactly one server lifecycle
mkdir -p "$HOME/.jarvis"
cat >"$HOME/.jarvis/llama.conf" <<CONF
MODEL="$HOME/jarvis/models/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"
HOST=127.0.0.1
PORT=$PORT_UNDER_TEST
CTX=4096
THREADS=4
PARALLEL=1
CACHE_RAM=512
CONF
export WATCHDOG_GRACE=2 WATCHDOG_EVERY=1
bash "$ROOT/termux/install-termux.sh" >/dev/null 2>&1
bash "$ROOT/termux/install-termux.sh" >/dev/null 2>&1   # second run while the server is crashing/hung: must not start a second one
check "install writes scripts" "$([ -x "$HOME/.jarvis/start-llama.sh" ] && [ -x "$HOME/.jarvis/llama-supervisor.sh" ] && echo ok || echo missing)"
check "install enables allow-external-apps" "$(grep -q '^allow-external-apps = true' "$HOME/.termux/termux.properties" && echo ok || echo missing)"
check "install writes boot script" "$([ -x "$HOME/.termux/boot/start-jarvis" ] && grep -q start-llama.sh "$HOME/.termux/boot/start-jarvis" && echo ok || echo missing)"
check "install keeps an existing llama.conf" "$(grep -q "PORT=$PORT_UNDER_TEST" "$HOME/.jarvis/llama.conf" && echo ok || echo overwritten)"
check "second install made a backup" "$(ls "$HOME/.jarvis"/start-llama.sh.bak-* >/dev/null 2>&1 && echo ok || echo none)"

# --- crash -> restart -> hang -> watchdog restart -> healthy
healthy=no
for i in $(seq 1 45); do
  if curl -sf --max-time 1 "http://127.0.0.1:$PORT_UNDER_TEST/health" >/dev/null 2>&1; then healthy=yes; break; fi
  sleep 1
done
runs="$(cat "$FAKE_COUNT" 2>/dev/null || echo 0)"
check "recovers to a healthy server after a crash and a hang" "$([ "$healthy" = yes ] && [ "$runs" -ge 3 ] && echo ok || echo "healthy=$healthy runs=$runs")"

# --- no duplicates when started again
before="$runs"
bash "$HOME/.jarvis/start-llama.sh"; bash "$HOME/.jarvis/start-llama.sh"; sleep 2
after="$(cat "$FAKE_COUNT")"
servers="$(pgrep -fc "$T/bin/llama-server" 2>/dev/null || echo 0)"
check "start-llama.sh does not start a second server" "$([ "$after" = "$before" ] && [ "$servers" -le 1 ] && echo ok || echo "runs $before->$after servers=$servers")"

# --- flags
check "passes -np 1, --cache-ram 512 and -c 4096" "$(grep -q -- '-np 1' "$FAKE_ARGS" && grep -q -- '--cache-ram 512' "$FAKE_ARGS" && grep -q -- '-c 4096' "$FAKE_ARGS" && echo ok || echo "$(head -1 "$FAKE_ARGS")")"
check "writes a log" "$(grep -q 'llama-server exited' "$HOME/.jarvis/llama.log" && echo ok || echo nolog)"

"$T/bin/tmux" kill-session -t jarvis-ai
pkill -f "[l]lama-supervisor[.]sh" 2>/dev/null; pkill -f "$T/bin/llama[-]server" 2>/dev/null
rm -rf "$T"
[ $fail = 0 ] && echo "== termux script tests passed" || { echo "== termux script tests FAILED"; exit 1; }
