package com.google.android.material.materialswitch
open class MaterialSwitch(c: android.content.Context) : android.widget.Switch(c)
