// Compile-check stubs for libraries that Maven Central/Google Maven would provide in the real Gradle build.
// They only describe signatures; nothing here is shipped in the app.
package androidx.core.content
import android.content.Context
import android.content.Intent
object ContextCompat {
    @JvmStatic fun checkSelfPermission(c: Context, p: String): Int = 0
    @JvmStatic fun startForegroundService(c: Context, i: Intent) {}
    @JvmStatic fun getColor(c: Context, id: Int): Int = 0
}
