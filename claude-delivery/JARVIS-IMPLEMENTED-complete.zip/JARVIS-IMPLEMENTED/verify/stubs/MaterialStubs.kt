package com.google.android.material.chip
import android.content.Context
open class ChipGroup(c: Context) : android.widget.LinearLayout(c) {
    fun interface OnCheckedStateChangeListener { fun onCheckedChanged(group: ChipGroup, checkedIds: List<Int>) }
    fun setOnCheckedStateChangeListener(l: OnCheckedStateChangeListener?) {}
}
