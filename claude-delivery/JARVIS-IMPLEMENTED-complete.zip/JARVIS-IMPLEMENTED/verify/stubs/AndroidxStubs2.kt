package androidx.core.app
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
object ServiceCompat { @JvmStatic fun startForeground(s: Service, id: Int, n: Notification, type: Int) {} }
class NotificationCompat {
    class Builder(c: Context, ch: String) {
        fun setSmallIcon(i: Int) = this
        fun setContentTitle(t: CharSequence?) = this
        fun setContentText(t: CharSequence?) = this
        fun setStyle(s: BigTextStyle) = this
        fun setOngoing(b: Boolean) = this
        fun setOnlyAlertOnce(b: Boolean) = this
        fun setContentIntent(p: PendingIntent?) = this
        fun addAction(i: Int, t: CharSequence?, p: PendingIntent?) = this
        fun build(): Notification = throw NotImplementedError()
    }
    class BigTextStyle { fun bigText(t: CharSequence?) = this }
}
