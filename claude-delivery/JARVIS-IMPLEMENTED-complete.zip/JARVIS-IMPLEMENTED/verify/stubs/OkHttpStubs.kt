package okhttp3
import java.util.concurrent.TimeUnit
class MediaType { companion object { fun String.toMediaType(): MediaType = MediaType() } }
class RequestBody { companion object { fun String.toRequestBody(contentType: MediaType? = null): RequestBody = RequestBody() } }
class ResponseBody { fun string(): String = ""; fun bytes(): ByteArray = ByteArray(0); fun byteStream(): java.io.InputStream = java.io.ByteArrayInputStream(ByteArray(0)) }
class Response : java.io.Closeable {
    val isSuccessful: Boolean get() = true
    val code: Int get() = 200
    val body: ResponseBody? get() = null
    override fun close() {}
}
interface Call { fun execute(): Response; fun cancel() }
class Request {
    class Builder {
        fun url(u: String) = this
        fun header(k: String, v: String) = this
        fun post(b: RequestBody) = this
        fun build() = Request()
    }
}
class OkHttpClient {
    class Builder {
        fun connectTimeout(t: Long, u: TimeUnit) = this
        fun readTimeout(t: Long, u: TimeUnit) = this
        fun writeTimeout(t: Long, u: TimeUnit) = this
        fun build() = OkHttpClient()
    }
    fun newBuilder() = Builder()
    fun newCall(r: Request): Call = throw NotImplementedError()
}
