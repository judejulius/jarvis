package androidx.appcompat.app
import android.content.Context
import android.content.DialogInterface
import android.view.View
open class AppCompatActivity : android.app.Activity()
class AlertDialog {
    class Builder(c: Context) {
        fun setTitle(t: CharSequence?) = this
        fun setMessage(t: CharSequence?) = this
        fun setView(v: View?) = this
        fun setPositiveButton(t: CharSequence?, l: DialogInterface.OnClickListener?) = this
        fun setNegativeButton(t: CharSequence?, l: DialogInterface.OnClickListener?) = this
        fun show(): AlertDialog = AlertDialog()
    }
}
