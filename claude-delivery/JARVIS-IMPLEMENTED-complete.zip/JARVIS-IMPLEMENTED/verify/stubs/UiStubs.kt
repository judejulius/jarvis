package com.jarvis.assistant.ui
import android.app.Activity
import android.view.View
import com.google.android.material.chip.ChipGroup
// Stand-ins for ui/UiKit.kt, ui/Insets.kt and the view-binding based MainActivity (need Material/AndroidX + generated code).
fun ChipGroup.addChoice(label: String, tag: String): View = View(context)
fun ChipGroup.select(tag: String) {}
val ChipGroup.selectedTag: String? get() = null
fun View.padForSystemBars(bottom: Boolean = true) {}
class MainActivity : Activity()

/** Stand-in for ui/TaskIsland.kt (view-binding based). Same public API. */
class TaskIsland(service: android.accessibilityservice.AccessibilityService) {
    enum class Mode { LISTENING, WORKING, DONE, FAILED }
    var expanded = false
    var onStop: () -> Unit = {}
    val isShowing get() = false
    fun listening(partialText: (() -> String)? = null, level: (() -> Float)? = null) {}
    fun working(task: String? = null) {}
    fun status(text: String) {}
    fun finish(success: Boolean, text: String) {}
    fun speaking(text: String, level: () -> Float?) {}
    fun speakingDone() {}
    fun hide() {}
    fun expand() {}
    fun collapse() {}
}
