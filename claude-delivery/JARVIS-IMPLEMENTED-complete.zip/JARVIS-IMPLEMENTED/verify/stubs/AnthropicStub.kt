package com.jarvis.assistant.agent
import com.jarvis.assistant.ProviderConfig
// Stand-in for AnthropicSession.kt, which needs the Anthropic SDK from Maven.
class AnthropicSession(config: ProviderConfig, system: String, tools: List<ToolSpec>) : ChatSession {
    override fun send(userText: String?, toolOutputs: List<ToolOutput>): AssistantTurn = AssistantTurn("", emptyList())
}
