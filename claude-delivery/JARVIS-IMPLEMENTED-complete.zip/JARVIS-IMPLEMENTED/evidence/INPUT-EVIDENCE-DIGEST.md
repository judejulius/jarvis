# Evidence provided by the user (digest) and how it was used

| Item | Value | Used for |
|---|---|---|
| Device | realme RMX3840, Android 16 (SDK 36), arm64, SoC `SM7435`, 6 CPUs visible via `nproc` (8 present), 7.4 GiB RAM, 7.5 GiB swap | server flags, memory assumptions |
| Termux | `googleplay.2026.10.09`, termux-tools 3.0.9, llama-cpp (version string `0 (unknown)`), tmux 3.6b; Termux:Boot installed (user confirmed) | install script, RUN_COMMAND risk note |
| Old boot script | `termux-wake-lock`; start tmux session only if no `llama-server` process exists; `-c 2048 -t 4`, port 8080 | audit finding 2, new supervisor |
| Server log | `n_parallel auto = 4`, prompt-cache limit 8192 MiB, model loaded and listening about 2.7 s after start, Qwen2.5 chat template with tool support | flags, start-wait budget |
| Timings (single samples) | 35-token prompt 1.6 s (21.9 tok/s); 167-token prompt after about 16 min idle 11.4 s (14.6 tok/s), total 13.0 s; 37-token prompt 5 s later 22.7 tok/s; generation 13.5-16.3 tok/s | prompt-size work, warm-up, routing policy |
| Memory snapshot | MemAvailable 2.19 GB of 7.59 GB, swap in use about 2.4 GB, llama-server VmRSS 86 MB / VmSwap 98 MB | audit hypothesis 10 |
| Tool-call test | `open_app {"name":"YouTube"}` returned correctly | tool calling confirmed to work with this build |
| Hinglish chat test | nonsensical reply | Auto routing sends Hindi/Hinglish chat to cloud |
| Git | clean tree, HEAD `9ed600d`; 31 Kotlin files, line counts identical to the ZIPs | patch base |
| Left blank by the user | app Base URL / model name, permissions, battery settings, voice-test results, app logs | not assumed: defaults chosen for loopback `127.0.0.1:8080/v1`, and everything device-dependent listed as unverified |
